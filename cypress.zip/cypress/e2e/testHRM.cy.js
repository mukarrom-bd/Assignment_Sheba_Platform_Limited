describe("HRM Leave Test", () => {
  it("log into the system and apply for leave", () => {
    cy.visit(
      "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
    );
    cy.get('input[name="username"]').type("Admin");
    cy.get('input[name="password"]').type("admin123");
    cy.get('button[type="submit"]').click();
    cy.url().should("include", "/dashboard");

    cy.get('a[href="/web/index.php/leave/viewLeaveModule"]').click();
    cy.url().should("include", "/viewLeaveList");
    cy.contains("a", "Apply").click();
    cy.url().should("include", "/applyLeave");

    // cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/leave/applyLeave');

    cy.get(".oxd-select-wrapper")
      .click() // Click the active element to open the dropdown
      .then(() => {
        cy.get('[role="listbox"]')
          .should("be.visible")
          .within(() => {
            // Search within the listbox context
            // cy.contains('US - Vacation').click();
            cy.contains("CAN - FMLA").click();
          });
      });

    // // Enter leave dates
    // cy.get(".oxd-input").type('2025-15-05');
    // cy.get('.oxd-input').first().type('2025-15-05', { force: true });
    // cy.get(".oxd-input oxd-input--active").first().invoke('val', '2025-15-05');
    // cy.get(".oxd-input").first().click();
    // cy.xpath('//*[@id="app"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[1]/div/div[2]/div/div/input').click();
    cy.get(
      "#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > input"
    )
      .clear()
      .type("2025-07-23");

    cy.get(
      "#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div:nth-child(2) > div > div:nth-child(2) > div > div:nth-child(2) > div > div > input"
    )
      .clear()
      .type("2025-07-27")
      .click();
    cy.wait(1000);
    cy.get(
      "#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div:nth-child(3) > div > div > div > div:nth-child(2) > div"
    ).click();
    cy.wait(1000);

    cy.get(
      "#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div:nth-child(3) > div > div > div > div:nth-child(2) > div"
    )
      .click()
      .then(() => {
        cy.get('[role="listbox"]')
          .should("be.visible")
          .within(() => {
            cy.contains("Start and End Day").click();
          });
      });

    cy.get(
      "#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div:nth-child(3) > div > div:nth-child(2) > div > div:nth-child(2) > div"
    )
      .click()
      .then(() => {
        cy.get('[role="listbox"]')
          .should("be.visible")
          .within(() => {
            cy.contains("Specify Time").click();
          });
      });

    cy.get(
      "#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div:nth-child(3) > div > div:nth-child(3) > div > div:nth-child(2) > div > div > input"
    )
      .clear()
      .type("10:45 AM")
      .click();

    cy.get(
      "#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div:nth-child(3) > div > div:nth-child(4) > div > div:nth-child(2) > div > div.oxd-time-input > input"
    )
      .clear()
      .type("02:00 PM")
      .click();

    cy.get(
      "#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div:nth-child(3) > div > div:nth-child(6) > div > div:nth-child(2) > div"
    )
      .click()
      .then(() => {
        cy.get('[role="listbox"]')
          .should("be.visible")
          .within(() => {
            cy.contains("Half Day - Morning").click();
          });
      });

    cy.get(
      "#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div:nth-child(4) > div > div > div > div:nth-child(2) > textarea"
    )
      .clear()
      .type("Here Some Comment!! I need leave urgently!!! ");

    // // Submit the leave application
    cy.get(
      "#app > div.oxd-layout.orangehrm-upgrade-layout > div.oxd-layout-container > div.oxd-layout-context > div > div > form > div.oxd-form-actions > button"
    ).click();
    cy.wait(3000);

    // Wait for the toast container to appear
    cy.get(".oxd-toast-container")
      .should("be.visible") // Ensure the toast is visible
      .within(() => {
        // Check the content of the toast message
        cy.contains("Successfully Saved").should("exist");
        // cy.contains('Sucess').should('exist');
      });
  });
});
